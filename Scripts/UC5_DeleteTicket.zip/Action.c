Action()
{

	lr_start_transaction("UC5_DeleteTicket");

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("open_home_page");
	
	web_reg_find("Text/IC=Welcome to the Web Tours site",
		LAST);

	web_add_cookie("MSO=SID&1681053557; DOMAIN=localhost");
	web_add_auto_header("DNT", 
		"1");
	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");
	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");
	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");
	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");
	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");
	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");
/*Correlation comment - Do not change!  Original value='136173.895990279HAAttttpHHftcAczpzzizf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("open_home_page", LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("enter_authorization");
	
	web_reg_find("Text/IC=Welcome, <b>{login}</b>, to the Web Tours",
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");
	web_add_auto_header("Sec-Fetch-User", 
		"?1");
	
	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t2.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=login.x", "Value=24", ENDITEM,
		"Name=login.y", "Value=12", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("enter_authorization", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("click_itinerary");
	
//	web_reg_find("Fail=Found",
//		"Text/IC=first_flightID",
//		LAST);
	
	web_reg_save_param("flightIDArr",
		"LB/IC=flightID\" value=\"",
		"RB/IC=\"  />",
		"Ord=all",
		LAST);

	web_reg_find("Text/IC=User wants the intineraries",
		LAST);

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_save_string(lr_paramarr_idx("flightIDArr",1), "first_flightID");
	
	lr_end_transaction("click_itinerary", LR_AUTO);
	
		lr_think_time(5);
	
	lr_start_transaction("delete_ticket");
	
//	web_reg_find("Text/IC=first_flightID",
//		LAST);
	
//	web_reg_find("Fail=Found",
//		"Text/IC=first_flightID",
//		LAST);
	
	web_reg_find("Fail=Found",
		"Text/IC={first_flightID}",
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	web_submit_form("itinerary.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM,
		"Name=removeFlights.x", "Value=68", ENDITEM, 
		"Name=removeFlights.y", "Value=10", ENDITEM,
		LAST);
	
//	web_submit_data("itinerary.pl", 
//		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
//		"Method=POST", 
//		"TargetFrame=", 
//		"RecContentType=text/html", 
//		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
//		"Snapshot=t4.inf", 
//		"Mode=HTML", 
//		ITEMDATA, 
//		"Name=1", "Value=on", ENDITEM, 
//		"Name=flightID", "Value=210297424-100296-JB", ENDITEM, 
//		"Name=flightID", "Value=210297416-177189-JB", ENDITEM, 
//		"Name=flightID", "Value=210297416-254112-JB", ENDITEM, 
//		"Name=flightID", "Value=210297424-331066-JB", ENDITEM, 
//		"Name=flightID", "Value=210297424-407989-JB", ENDITEM, 
//		"Name=flightID", "Value=33492785-48-JB", ENDITEM, 
//		"Name=flightID", "Value=0-0-P", ENDITEM, 
//		"Name=flightID", "Value=0-0-M", ENDITEM, 
//		"Name=flightID", "Value=4-0-60", ENDITEM, 
//		"Name=flightID", "Value=8-0-60", ENDITEM, 
//		"Name=flightID", "Value=1-0-60", ENDITEM, 
//		"Name=flightID", "Value=0-0-5\r\n", ENDITEM, 
//		"Name=flightID", "Value=6-1-5\r\n", ENDITEM, 
//		"Name=flightID", "Value=8-1-5\r\n", ENDITEM, 
//		"Name=flightID", "Value=12-1-5\r\n", ENDITEM, 
//		"Name=flightID", "Value=15-1-5\r\n", ENDITEM, 
//		"Name=flightID", "Value=21-1-5\r\n", ENDITEM, 
//		"Name=flightID", "Value=4-1-22", ENDITEM, 
//		"Name=flightID", "Value=0-1-\r\n", ENDITEM, 
//		"Name=flightID", "Value=0-1-\r\n", ENDITEM, 
//		"Name=flightID", "Value=4-1-22", ENDITEM, 
//		"Name=flightID", "Value=0-1-\r\n", ENDITEM, 
//		"Name=flightID", "Value=4-1-22", ENDITEM, 
//		"Name=flightID", "Value=4-1-22", ENDITEM, 
//		"Name=flightID", "Value=4-1-22", ENDITEM, 
//		"Name=flightID", "Value=4-2-22", ENDITEM, 
//		"Name=flightID", "Value=4-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-22", ENDITEM, 
//		"Name=flightID", "Value=0-2-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=0-3-2", ENDITEM, 
//		"Name=flightID", "Value=34-3-2", ENDITEM, 
//		"Name=flightID", "Value=32-3-2", ENDITEM, 
//		"Name=flightID", "Value=30-3-2", ENDITEM, 
//		"Name=flightID", "Value=6-3-2", ENDITEM, 
//		"Name=flightID", "Value=19-4-22", ENDITEM, 
//		"Name=flightID", "Value=1-4-22", ENDITEM, 
//		"Name=flightID", "Value=4-4-22", ENDITEM, 
//		"Name=flightID", "Value=4-4-22", ENDITEM, 
//		"Name=flightID", "Value=5-4-22", ENDITEM, 
//		"Name=flightID", "Value=0-4-22", ENDITEM, 
//		"Name=flightID", "Value=8-4-22", ENDITEM, 
//		"Name=flightID", "Value=3-4-22", ENDITEM, 
//		"Name=flightID", "Value=25-4-22", ENDITEM, 
//		"Name=flightID", "Value=0-4-ds", ENDITEM, 
//		"Name=flightID", "Value=0-4-\r\n", ENDITEM, 
//		"Name=flightID", "Value=17-4-22", ENDITEM, 
//		"Name=flightID", "Value=17-4-22", ENDITEM, 
//		"Name=flightID", "Value=8-5-22", ENDITEM, 
//		"Name=flightID", "Value=28-5-22", ENDITEM, 
//		"Name=flightID", "Value=28-5-22", ENDITEM, 
//		"Name=flightID", "Value=8-5-2s", ENDITEM, 
//		"Name=flightID", "Value=8-5-22", ENDITEM, 
//		"Name=flightID", "Value=0-5-\r\n", ENDITEM, 
//		"Name=flightID", "Value=0-5-\r\n", ENDITEM, 
//		"Name=flightID", "Value=35-5-22", ENDITEM, 
//		"Name=flightID", "Value=31-5-22", ENDITEM, 
//		"Name=flightID", "Value=33-5-22", ENDITEM, 
//		"Name=flightID", "Value=34-5-22", ENDITEM, 
//		"Name=flightID", "Value=8-5-22", ENDITEM, 
//		"Name=flightID", "Value=19-5-22", ENDITEM, 
//		"Name=flightID", "Value=12-6-22", ENDITEM, 
//		"Name=flightID", "Value=18-6-22", ENDITEM, 
//		"Name=flightID", "Value=8-6-22", ENDITEM, 
//		"Name=flightID", "Value=3-6-22", ENDITEM, 
//		"Name=flightID", "Value=3-6-22", ENDITEM, 
//		"Name=flightID", "Value=12-6-22", ENDITEM, 
//		"Name=flightID", "Value=32-6-22", ENDITEM, 
//		"Name=flightID", "Value=10-6-22", ENDITEM, 
//		"Name=flightID", "Value=16-6-22", ENDITEM, 
//		"Name=flightID", "Value=36-6-22", ENDITEM, 
//		"Name=flightID", "Value=22-6-22", ENDITEM, 
//		"Name=flightID", "Value=13-6-22", ENDITEM, 
//		"Name=flightID", "Value=1-6-22", ENDITEM, 
//		"Name=flightID", "Value=12-7-\r\n", ENDITEM, 
//		"Name=flightID", "Value=7-7-22", ENDITEM, 
//		"Name=flightID", "Value=17-7-22", ENDITEM, 
//		"Name=flightID", "Value=9-7-22", ENDITEM, 
//		"Name=flightID", "Value=28-73-22", ENDITEM, 
//		"Name=removeFlights.x", "Value=68", ENDITEM, 
//		"Name=removeFlights.y", "Value=10", ENDITEM, 
//		"Name=.cgifields", "Value=33", ENDITEM, 
//		"Name=.cgifields", "Value=32", ENDITEM, 
//		"Name=.cgifields", "Value=90", ENDITEM, 
//		"Name=.cgifields", "Value=63", ENDITEM, 
//		"Name=.cgifields", "Value=21", ENDITEM, 
//		"Name=.cgifields", "Value=71", ENDITEM, 
//		"Name=.cgifields", "Value=7", ENDITEM, 
//		"Name=.cgifields", "Value=80", ENDITEM, 
//		"Name=.cgifields", "Value=26", ENDITEM, 
//		"Name=.cgifields", "Value=18", ENDITEM, 
//		"Name=.cgifields", "Value=72", ENDITEM, 
//		"Name=.cgifields", "Value=16", ENDITEM, 
//		"Name=.cgifields", "Value=44", ENDITEM, 
//		"Name=.cgifields", "Value=55", ENDITEM, 
//		"Name=.cgifields", "Value=84", ENDITEM, 
//		"Name=.cgifields", "Value=74", ENDITEM, 
//		"Name=.cgifields", "Value=27", ENDITEM, 
//		"Name=.cgifields", "Value=95", ENDITEM, 
//		"Name=.cgifields", "Value=57", ENDITEM, 
//		"Name=.cgifields", "Value=61", ENDITEM, 
//		"Name=.cgifields", "Value=20", ENDITEM, 
//		"Name=.cgifields", "Value=92", ENDITEM, 
//		"Name=.cgifields", "Value=89", ENDITEM, 
//		"Name=.cgifields", "Value=10", ENDITEM, 
//		"Name=.cgifields", "Value=31", ENDITEM, 
//		"Name=.cgifields", "Value=35", ENDITEM, 
//		"Name=.cgifields", "Value=11", ENDITEM, 
//		"Name=.cgifields", "Value=91", ENDITEM, 
//		"Name=.cgifields", "Value=78", ENDITEM, 
//		"Name=.cgifields", "Value=48", ENDITEM, 
//		"Name=.cgifields", "Value=87", ENDITEM, 
//		"Name=.cgifields", "Value=93", ENDITEM, 
//		"Name=.cgifields", "Value=77", ENDITEM, 
//		"Name=.cgifields", "Value=65", ENDITEM, 
//		"Name=.cgifields", "Value=29", ENDITEM, 
//		"Name=.cgifields", "Value=50", ENDITEM, 
//		"Name=.cgifields", "Value=39", ENDITEM, 
//		"Name=.cgifields", "Value=64", ENDITEM, 
//		"Name=.cgifields", "Value=58", ENDITEM, 
//		"Name=.cgifields", "Value=41", ENDITEM, 
//		"Name=.cgifields", "Value=12", ENDITEM, 
//		"Name=.cgifields", "Value=15", ENDITEM, 
//		"Name=.cgifields", "Value=81", ENDITEM, 
//		"Name=.cgifields", "Value=52", ENDITEM, 
//		"Name=.cgifields", "Value=60", ENDITEM, 
//		"Name=.cgifields", "Value=56", ENDITEM, 
//		"Name=.cgifields", "Value=73", ENDITEM, 
//		"Name=.cgifields", "Value=66", ENDITEM, 
//		"Name=.cgifields", "Value=45", ENDITEM, 
//		"Name=.cgifields", "Value=86", ENDITEM, 
//		"Name=.cgifields", "Value=76", ENDITEM, 
//		"Name=.cgifields", "Value=19", ENDITEM, 
//		"Name=.cgifields", "Value=62", ENDITEM, 
//		"Name=.cgifields", "Value=54", ENDITEM, 
//		"Name=.cgifields", "Value=67", ENDITEM, 
//		"Name=.cgifields", "Value=70", ENDITEM, 
//		"Name=.cgifields", "Value=68", ENDITEM, 
//		"Name=.cgifields", "Value=2", ENDITEM, 
//		"Name=.cgifields", "Value=17", ENDITEM, 
//		"Name=.cgifields", "Value=1", ENDITEM, 
//		"Name=.cgifields", "Value=88", ENDITEM, 
//		"Name=.cgifields", "Value=30", ENDITEM, 
//		"Name=.cgifields", "Value=82", ENDITEM, 
//		"Name=.cgifields", "Value=25", ENDITEM, 
//		"Name=.cgifields", "Value=28", ENDITEM, 
//		"Name=.cgifields", "Value=83", ENDITEM, 
//		"Name=.cgifields", "Value=75", ENDITEM, 
//		"Name=.cgifields", "Value=40", ENDITEM, 
//		"Name=.cgifields", "Value=14", ENDITEM, 
//		"Name=.cgifields", "Value=69", ENDITEM, 
//		"Name=.cgifields", "Value=59", ENDITEM, 
//		"Name=.cgifields", "Value=49", ENDITEM, 
//		"Name=.cgifields", "Value=24", ENDITEM, 
//		"Name=.cgifields", "Value=53", ENDITEM, 
//		"Name=.cgifields", "Value=79", ENDITEM, 
//		"Name=.cgifields", "Value=22", ENDITEM, 
//		"Name=.cgifields", "Value=42", ENDITEM, 
//		"Name=.cgifields", "Value=46", ENDITEM, 
//		"Name=.cgifields", "Value=23", ENDITEM, 
//		"Name=.cgifields", "Value=13", ENDITEM, 
//		"Name=.cgifields", "Value=6", ENDITEM, 
//		"Name=.cgifields", "Value=85", ENDITEM, 
//		"Name=.cgifields", "Value=3", ENDITEM, 
//		"Name=.cgifields", "Value=36", ENDITEM, 
//		"Name=.cgifields", "Value=94", ENDITEM, 
//		"Name=.cgifields", "Value=9", ENDITEM, 
//		"Name=.cgifields", "Value=51", ENDITEM, 
//		"Name=.cgifields", "Value=47", ENDITEM, 
//		"Name=.cgifields", "Value=8", ENDITEM, 
//		"Name=.cgifields", "Value=38", ENDITEM, 
//		"Name=.cgifields", "Value=4", ENDITEM, 
//		"Name=.cgifields", "Value=34", ENDITEM, 
//		"Name=.cgifields", "Value=37", ENDITEM, 
//		"Name=.cgifields", "Value=43", ENDITEM, 
//		"Name=.cgifields", "Value=5", ENDITEM, 
//		LAST);
	
	lr_end_transaction("delete_ticket", LR_AUTO);

	lr_think_time(5);
	
	lr_end_transaction("UC5_DeleteTicket", LR_AUTO);

	return 0;
}