#ifndef VUSER_WEBSOCKET_BUFFER_HEADER
#define VUSER_WEBSOCKET_BUFFER_HEADER

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive0[] = "0{\"sid\":\"cC52WCSVa15SvdmfuSkn\",\"upgrades\":[],\"pingInterval\":30000,\"ping"
                        "Timeout\":20000,\"maxPayload\":10000000}";
long WebSocketReceiveLen0   = sizeof(WebSocketReceive0) - 1;	// (record-time: 108 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive1[] = "40";
long WebSocketReceiveLen1   = sizeof(WebSocketReceive1) - 1;	// (record-time: 2 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive2[] = "42[\"message\",{\"action\":\"sleep\",\"delay\":3600}]";
long WebSocketReceiveLen2   = sizeof(WebSocketReceive2) - 1;	// (record-time: 45 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive3[] = "41";
long WebSocketReceiveLen3   = sizeof(WebSocketReceive3) - 1;	// (record-time: 2 bytes)

#endif
